# Blueprint Zecapão SaaS 0.1

## 1. O que NÃO mexer agora
- Auth e Passport
- Carrinho e checkout
- Order / OrderDetail / OrderTransaction
- Wallet / Loyalty / Cashback
- DeliveryMan / tracking
- RestaurantSubscription / SubscriptionPackage
- Coupon / Campaign / Banner
- Zone e opções de entrega

## 2. Compatibilidade semântica
A tabela e model `restaurants` permanecem. No produto, o termo exibido será "Estabelecimento". Renomear internamente apenas numa versão maior.

## 3. Novas entidades
### Tenant
Quem licencia/opera a plataforma. Ex.: Zecapão Tecnologia, parceiro de Itacaré etc.

### Destination
Instância territorial e de marca. Ex.: Vale do Capão. Carrega host, identidade, timezone, moeda e feature flags.

### BusinessType
Classifica o estabelecimento pelo modelo de negócio e capacidades, não por culinária.

## 4. Fluxo de escopo
App abre -> resolve destino -> carrega identidade -> lista tipos de negócio -> lista estabelecimentos desse destino -> checkout preservado.

## 5. Regras para Fase 0
- `zones.destination_id` obrigatório depois da migração de dados.
- `restaurants.destination_id` obrigatório depois da migração de dados.
- `orders.destination_id` preenchido no momento da criação do pedido.
- Nunca confiar em destination_id enviado pelo cliente no checkout; derivar do restaurante/zone no servidor.
- Admin superadmin pode ver todos os destinos; operador local só os destinos do seu tenant.

## 6. Flutter
Adicionar `destinationSlug` à configuração local e enviar `X-Destination-Slug` no ApiClient. No splash, buscar `/api/v1/destination/current` e aplicar `brand_settings`. A home deve usar BusinessType acima de categorias gastronômicas.

## 7. Fase seguinte
Criar entidade `offers`/`listings` para hospedagem, experiências e serviços. Não force reservas a caberem em `foods`; mantenha `foods` para itens transacionais de catálogo e crie um domínio novo para disponibilidade/agendamento.
