<?php
namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Models\BusinessType;
use Illuminate\Http\Request;

class DestinationController extends Controller
{
    public function current(Request $request)
    {
        $destination = $request->attributes->get('destination');
        return response()->json([
            'id' => $destination->id,
            'name' => $destination->name,
            'slug' => $destination->slug,
            'app_name' => $destination->app_name,
            'city' => $destination->city,
            'state' => $destination->state,
            'timezone' => $destination->timezone,
            'currency' => $destination->currency,
            'logo' => $destination->logo,
            'cover_image' => $destination->cover_image,
            'brand_settings' => $destination->brand_settings,
            'feature_flags' => $destination->feature_flags,
        ]);
    }

    public function businessTypes(Request $request)
    {
        return response()->json(BusinessType::query()->where('status', true)->orderBy('priority')->orderBy('name')->get());
    }
}
