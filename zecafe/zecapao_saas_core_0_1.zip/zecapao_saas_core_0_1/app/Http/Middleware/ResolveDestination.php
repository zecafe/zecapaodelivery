<?php
namespace App\Http\Middleware;

use App\Models\Destination;
use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class ResolveDestination
{
    public function handle(Request $request, Closure $next): Response
    {
        $slug = $request->header('X-Destination-Slug') ?: $request->query('destination');

        $destination = Destination::query()
            ->where('status', true)
            ->when($slug, fn($q) => $q->where('slug', $slug))
            ->when(!$slug, function ($q) use ($request) {
                $q->where(function ($q2) use ($request) {
                    $q2->where('host', $request->getHost())->orWhere('is_default', true);
                });
            })
            ->orderByDesc('host')
            ->orderByDesc('is_default')
            ->first();

        if (!$destination) {
            return response()->json(['errors' => [['code' => 'destination_not_found', 'message' => 'Destino não encontrado.']]], 404);
        }

        $request->attributes->set('destination', $destination);
        return $next($request);
    }
}
