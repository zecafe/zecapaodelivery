<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Tenant extends Model
{
    protected $guarded = ['id'];
    protected $casts = ['status' => 'boolean', 'settings' => 'array'];
    public function destinations(): HasMany { return $this->hasMany(Destination::class); }
}
