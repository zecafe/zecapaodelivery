<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Destination extends Model
{
    protected $guarded = ['id'];
    protected $casts = ['status'=>'boolean','is_default'=>'boolean','brand_settings'=>'array','feature_flags'=>'array'];
    public function tenant(): BelongsTo { return $this->belongsTo(Tenant::class); }
    public function zones(): HasMany { return $this->hasMany(Zone::class); }
    public function restaurants(): HasMany { return $this->hasMany(Restaurant::class); }
    public function orders(): HasMany { return $this->hasMany(Order::class); }
    public function banners(): HasMany { return $this->hasMany(Banner::class); }
}
