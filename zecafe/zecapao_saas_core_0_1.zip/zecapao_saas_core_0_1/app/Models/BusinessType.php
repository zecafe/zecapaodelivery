<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;

class BusinessType extends Model
{
    protected $guarded = ['id'];
    protected $casts = ['status'=>'boolean','supports_catalog'=>'boolean','supports_delivery'=>'boolean','supports_booking'=>'boolean','supports_request'=>'boolean','settings'=>'array'];
    public function restaurants(): HasMany { return $this->hasMany(Restaurant::class); }
}
