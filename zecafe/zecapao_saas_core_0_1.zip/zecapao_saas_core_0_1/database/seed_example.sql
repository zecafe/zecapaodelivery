-- EXEMPLO. Ajuste IDs antes de usar.
INSERT INTO tenants (name, slug, status, created_at, updated_at)
VALUES ('Zecapão Tecnologia', 'zecapao', 1, NOW(), NOW());

INSERT INTO destinations (tenant_id, name, slug, city, state, country, timezone, currency, app_name, is_default, status, created_at, updated_at)
SELECT id, 'Vale do Capão', 'vale-do-capao', 'Palmeiras', 'BA', 'BR', 'America/Bahia', 'BRL', 'Zecapão', 1, 1, NOW(), NOW()
FROM tenants WHERE slug='zecapao' LIMIT 1;

INSERT INTO business_types (name, slug, priority, supports_catalog, supports_delivery, supports_booking, supports_request, status, created_at, updated_at) VALUES
('Comer & Beber','food-drink',1,1,1,0,0,1,NOW(),NOW()),
('Mercados','market',2,1,1,0,0,1,NOW(),NOW()),
('Lojas','shops',3,1,1,0,1,1,NOW(),NOW()),
('Hospedagem','lodging',4,1,0,1,1,1,NOW(),NOW()),
('Passeios & Experiências','experiences',5,1,0,1,1,1,NOW(),NOW()),
('Turismo & Serviços','services',6,1,0,0,1,1,NOW(),NOW()),
('Eventos','events',7,1,0,1,1,1,NOW(),NOW());
