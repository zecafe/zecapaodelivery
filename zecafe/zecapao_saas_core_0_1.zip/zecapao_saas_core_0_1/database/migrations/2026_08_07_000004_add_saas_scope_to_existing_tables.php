<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void {
        Schema::table('zones', function (Blueprint $table) {
            $table->foreignId('destination_id')->nullable()->after('id')->constrained('destinations')->nullOnDelete();
            $table->index(['destination_id', 'status']);
        });

        Schema::table('restaurants', function (Blueprint $table) {
            $table->foreignId('destination_id')->nullable()->after('id')->constrained('destinations')->nullOnDelete();
            $table->foreignId('business_type_id')->nullable()->after('destination_id')->constrained('business_types')->nullOnDelete();
            $table->json('service_modes')->nullable();
            $table->index(['destination_id', 'business_type_id', 'status'], 'restaurants_destination_type_status_idx');
        });

        Schema::table('orders', function (Blueprint $table) {
            $table->foreignId('destination_id')->nullable()->after('id')->constrained('destinations')->nullOnDelete();
            $table->index(['destination_id', 'created_at']);
        });

        Schema::table('banners', function (Blueprint $table) {
            $table->foreignId('destination_id')->nullable()->after('id')->constrained('destinations')->nullOnDelete();
            $table->index(['destination_id', 'status']);
        });
    }

    public function down(): void {
        Schema::table('banners', fn (Blueprint $table) => $table->dropConstrainedForeignId('destination_id'));
        Schema::table('orders', fn (Blueprint $table) => $table->dropConstrainedForeignId('destination_id'));
        Schema::table('restaurants', function (Blueprint $table) {
            $table->dropConstrainedForeignId('business_type_id');
            $table->dropConstrainedForeignId('destination_id');
            $table->dropColumn('service_modes');
        });
        Schema::table('zones', fn (Blueprint $table) => $table->dropConstrainedForeignId('destination_id'));
    }
};
