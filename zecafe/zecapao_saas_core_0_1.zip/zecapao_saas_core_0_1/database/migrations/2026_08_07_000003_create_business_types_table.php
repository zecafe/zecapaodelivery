<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void {
        Schema::create('business_types', function (Blueprint $table) {
            $table->id();
            $table->string('name');
            $table->string('slug')->unique();
            $table->string('icon')->nullable();
            $table->tinyInteger('priority')->default(0);
            $table->boolean('supports_catalog')->default(true);
            $table->boolean('supports_delivery')->default(false);
            $table->boolean('supports_booking')->default(false);
            $table->boolean('supports_request')->default(false);
            $table->boolean('status')->default(true);
            $table->json('settings')->nullable();
            $table->timestamps();
        });
    }
    public function down(): void { Schema::dropIfExists('business_types'); }
};
