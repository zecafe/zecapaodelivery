<?php
// Adicionar imports em routes/api/v1/api.php:
use App\Http\Controllers\Api\V1\DestinationController;

// Registrar alias do middleware `destination` no bootstrap/app.php (Laravel 12),
// apontando para App\Http\Middleware\ResolveDestination::class.

Route::middleware('destination')->group(function () {
    Route::get('destination/current', [DestinationController::class, 'current']);
    Route::get('destination/business-types', [DestinationController::class, 'businessTypes']);
});
