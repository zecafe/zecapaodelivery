# Zecapão SaaS Core 0.1

Starter técnico para evoluir a base StackFood 9.1 para uma plataforma SaaS multi-destino.

## Arquitetura
Tenant/Operador -> Destino -> Zonas -> Estabelecimentos -> Pedidos

- `tenants`: operador/licenciado da plataforma.
- `destinations`: marca territorial/white-label (ex.: Vale do Capão).
- `business_types`: tipologia ampla do estabelecimento (restaurante, mercado, loja, turismo, serviço etc.).
- `zones`: permanecem estritamente logísticas e recebem `destination_id`.
- `restaurants`: são mantidos por compatibilidade, mas passam a representar `establishments` conceitualmente.
- `orders`: recebem `destination_id` para isolamento, relatórios e repasses.
- `banners`: recebem `destination_id` para home e campanhas por destino.

## Estratégia de compatibilidade
Não renomear a tabela `restaurants` na Fase 0. Isso quebraria muitos controllers, APIs e o app Flutter. A UI pode chamar de "Estabelecimento" enquanto o backend mantém o nome legado até uma migração futura.

## Resolução de destino
O middleware `ResolveDestination` aceita, nesta ordem:
1. header `X-Destination-Slug`
2. query string `destination`
3. hostname configurado em `destinations.host`
4. destino marcado como default

O destino resolvido é colocado em `request()->attributes['destination']`.

## Aplicação
Copie os arquivos para uma branch/cópia da instalação Laravel, revise namespaces e execute migrations apenas em ambiente de desenvolvimento com backup.

## Próxima etapa
1. Criar endpoints de home por destino.
2. Filtrar Zone/Restaurant/Banner por destination_id.
3. Popular tenant e destino #001.
4. Adaptar Flutter para enviar `X-Destination-Slug`.
5. Criar módulos turísticos sem quebrar checkout de alimentos.
